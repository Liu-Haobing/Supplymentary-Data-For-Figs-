import os
import torch
import torchvision
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from tqdm import tqdm
from sklearn.metrics import r2_score

# Step 1: 定义Dataset类
class FocusDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        self.images = []
        self.labels = []

        # 遍历目录读取所有图片及其焦平面距离
        for filename in os.listdir(image_dir):
            if filename.endswith('.png'):
                # 解析文件名，获取距离焦平面距离
                name_parts = filename.split('_')
                distance = int(name_parts[0])  # num是焦平面距离
                self.images.append(filename)
                self.labels.append(distance)

        self.labels = np.array(self.labels)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        image_path = os.path.join(self.image_dir, self.images[idx])
        image = Image.open(image_path).convert('RGB')

        if self.transform:
            image = self.transform(image)

        label = torch.tensor(self.labels[idx], dtype=torch.float32)
        return image, label

# Step 2: 数据准备和划分
image_dir = 'dataset_1_aug/train'  # 读取增强后的数据集
transform = transforms.Compose([
    transforms.Resize((32, 32)),  # 统一大小，130x130调整到128x128
    transforms.ToTensor()
])

# 创建数据集对象
dataset = FocusDataset(image_dir, transform)
train_data, val_data = train_test_split(dataset, test_size=0.2, random_state=42)

train_loader = DataLoader(train_data, batch_size=32, shuffle=True)
val_loader = DataLoader(val_data, batch_size=32, shuffle=False)

# Step 3: 定义ResNet模型（使用预训练模型）
class ResNetForRegression(nn.Module):
    def __init__(self, pretrain=True):
        super(ResNetForRegression, self).__init__()
        self.resnet = models.resnet18(pretrained=pretrain)
        self.resnet.fc = nn.Sequential(
            nn.Linear(self.resnet.fc.in_features, 512),
            nn.BatchNorm1d(512),  # 添加BatchNorm
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Linear(512, 1)
        )

    def forward(self, x):
        return self.resnet(x)

# Step 4: 模型训练
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = ResNetForRegression().to(device)
criterion = nn.SmoothL1Loss()  # 均方误差损失
optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-5)


# 训练过程
epochs = 200
train_losses = []
val_losses = []

# 保存最优模型的路径
best_model_path = "best_model.pth"
best_val_loss = float('inf')  # 初始时，最小验证集损失为正无穷大

for epoch in range(epochs):
    model.train()
    running_loss = 0.0
    for images, labels in tqdm(train_loader, desc=f"Epoch {epoch + 1}/{epochs}"):
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(images).squeeze()

        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    avg_train_loss = running_loss / len(train_loader)
    train_losses.append(avg_train_loss)

    # 验证过程
    model.eval()
    running_val_loss = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images).squeeze()
            loss = criterion(outputs, labels)
            running_val_loss += loss.item()

    avg_val_loss = running_val_loss / len(val_loader)
    val_losses.append(avg_val_loss)

    print(f"Train Loss: {avg_train_loss:.4f}, Validation Loss: {avg_val_loss:.4f}")

    # 保存验证集损失最小的模型
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        torch.save(model.state_dict(), best_model_path)
        print(f"Saved best model with validation loss: {best_val_loss:.4f}")

# Step 5: 加载最优模型
model.load_state_dict(torch.load(best_model_path))

# Step 6: 可视化训练和验证损失
plt.plot(range(epochs), train_losses, label="Train Loss")
plt.plot(range(epochs), val_losses, label="Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.title("Training and Validation Loss")
plt.savefig('loss_plot.png')
plt.show()

# Step 7: 保存预测结果到CSV文件
model.eval()
results = []
true_labels = []
predicted_labels = []
with torch.no_grad():
    for i, (images, labels) in enumerate(val_loader):
        images = images.to(device)
        outputs = model(images).squeeze()
        for j in range(len(outputs)):
            results.append({
                'Image': val_data[i * len(images) + j][0],  # 获取正确的图片路径
                'True Distance': labels[j].item(),
                'Predicted Distance': outputs[j].item()
            })
            true_labels.append(labels[j].item())
            predicted_labels.append(outputs[j].item())

results_df = pd.DataFrame(results)
results_df.to_csv('predictions.csv', index=False)

# Step 8: 可视化并保存预测的图片
sample_images, sample_labels = next(iter(val_loader))
sample_images = sample_images.to(device)
sample_labels = sample_labels.to(device)
predicted_distances = model(sample_images).squeeze().cpu().detach().numpy()

fig, axes = plt.subplots(4, 4, figsize=(12, 12))
axes = axes.flatten()

for i in range(16):
    ax = axes[i]
    ax.imshow(sample_images[i].cpu().numpy().transpose(1, 2, 0))  # 转回 HWC 格式
    ax.set_title(f"True: {sample_labels[i].item()} Pred: {predicted_distances[i]:.2f}")
    ax.axis('off')

plt.tight_layout()
plt.savefig('sample_predictions.png')
plt.show()

# Step 9: 绘制回归曲线并计算R²
plt.scatter(true_labels, predicted_labels, color='blue')
plt.plot([min(true_labels), max(true_labels)], [min(true_labels), max(true_labels)], color='red', linestyle='--')
plt.xlabel('True Distance')
plt.ylabel('Predicted Distance')
plt.title('True vs Predicted Distance')

# 计算R²
r2 = r2_score(true_labels, predicted_labels)
plt.text(0.1, 0.9, f'R² = {r2:.4f}', transform=plt.gca().transAxes, fontsize=12, verticalalignment='top')

plt.savefig('regression_curve.png')
plt.show()
