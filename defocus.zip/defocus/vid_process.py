import cv2
import torch
import numpy as np
import pandas as pd
from torch import nn, optim
import matplotlib.pyplot as plt
from torchvision import transforms, models
from PIL import Image

# 1. 加载训练好的模型
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class ResNetForRegression(nn.Module):
    def __init__(self, pretrain=True):
        super(ResNetForRegression, self).__init__()
        self.resnet = models.resnet18(pretrained=pretrain)
        self.resnet.fc = nn.Sequential(
            nn.Linear(self.resnet.fc.in_features, 512),
            nn.BatchNorm1d(512),  # 添加BatchNorm
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Linear(512, 1)
        )

    def forward(self, x):
        return self.resnet(x)

# 加载已训练的模型
model = ResNetForRegression().to(device)
model.load_state_dict(torch.load("best_model.pth"))
model.eval()

# 2. 定义数据转换操作
transform = transforms.Compose([
    transforms.Resize((32, 32)),  # Resize to 128x128
    transforms.ToTensor()
])

# 3. 视频读取与预测
video_path = 'test1.mp4'  # 视频文件路径
cap = cv2.VideoCapture(video_path)

# 确保视频能成功打开
if not cap.isOpened():
    print("Error: Unable to open video.")
    exit()

# 提取多个中心坐标（例如多个对象的坐标），确保这些坐标在视频图像尺寸内
centers = [(673, 267), (164,532), (572, 956)]  # 举例多个坐标，实际需要根据视频调整

# 结果保存
height_values = []
timestamps = []

frame_rate = cap.get(cv2.CAP_PROP_FPS)  # 获取视频帧率
frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

# 4. 提取每一帧并进行预测
frame_num = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break  # 到达视频末尾

    frame_heights = []  # 用于保存当前帧各个中心点的预测值
    rad = 38
    for center_x, center_y in centers:
        # 提取中心为 (center_x, center_y) 的 128x128 区域
        x1 = center_x - rad
        x2 = center_x + rad
        y1 = center_y - rad
        y2 = center_y + rad

        cropped_frame = frame[y1:y2, x1:x2]  # 128x128 图像区域

        # 转换为 PIL 图片并应用预处理
        cropped_image = Image.fromarray(cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2RGB))
        input_tensor = transform(cropped_image).unsqueeze(0).to(device)  # 扩展维度 (batch_size, channels, height, width)

        # 使用模型进行预测
        with torch.no_grad():
            predicted_height = model(input_tensor).squeeze().cpu().item()  # 获取预测的高度值

        frame_heights.append(predicted_height)  # 保存该对象的预测结果

    # 计算多个对象的平均高度值作为当前帧的预测结果
    avg_height = np.mean(frame_heights)

    # 保存结果
    timestamps.append(frame_num / frame_rate)  # 计算时间（秒）
    height_values.append(avg_height)

    frame_num += 1

# 释放视频文件
cap.release()

# 5. 绘制高度变化曲线
plt.plot(timestamps, height_values, label="Predicted Height")
plt.xlabel('Time (seconds)')
plt.ylabel('Predicted Height')
plt.title('Height vs Time')
plt.legend()
plt.grid(True)
plt.savefig('height_vs_time.png')
plt.show()

# 6. 保存预测结果到 CSV 文件
df = pd.DataFrame({
    'Time (s)': timestamps,
    'Predicted Height': height_values
})
df.to_csv('predicted_heights.csv', index=False)

print("预测完成，图像和数据已保存！")
