import cv2
import numpy as np
import os
from PIL import Image
from tqdm import tqdm

# Step 1: 读取指定文件夹中的图片
image_dir = '1-1930'  # 假设图片文件夹路径为 "images"
image_files = [f for f in os.listdir(image_dir) if f.endswith('.png')]


# 自定义排序：按文件名中的焦平面距离排序（提取数字部分并按数值排序）
def extract_distance(file_name):
    # 提取文件名中的焦平面距离
    name_parts = file_name.split('.')  # 假设文件名形如 "-20_abc.png"
    distance = int(name_parts[0])  # 取出焦平面距离部分
    return distance


# 按照焦平面距离进行排序
image_files.sort(key=extract_distance)

# 获取排序后的图片路径
image_paths = [os.path.join(image_dir, f) for f in image_files]


# Step 2: 定义平滑过渡效果（线性插值）
def create_transition_frame(img1, img2, alpha):
    return cv2.addWeighted(img1, 1 - alpha, img2, alpha, 0)


# Step 3: 创建视频
video_name = 'output_video.mp4'
fps = 30  # 视频的帧率
frame_duration = 1  # 每张图片展示1秒
frames_per_image = fps * frame_duration

# 获取图像的尺寸
img = cv2.imread(image_paths[0])  # 读取第一张图像
height, width, channels = img.shape

# 设置视频写入器
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
video_writer = cv2.VideoWriter(video_name, fourcc, fps, (width, height))

# Step 4: 遍历所有图片，添加平滑过渡效果并写入视频
for i in tqdm(range(len(image_paths) - 1)):
    img1 = cv2.imread(image_paths[i])
    img2 = cv2.imread(image_paths[i + 1])

    # 每两张图片之间插入多个平滑过渡帧
    for j in range(frames_per_image):
        alpha = j / frames_per_image  # 逐渐过渡
        transition_frame = create_transition_frame(img1, img2, alpha)
        video_writer.write(transition_frame)

# Step 5: 完成视频的写入
video_writer.release()
print(f"视频已保存至 {video_name}")
