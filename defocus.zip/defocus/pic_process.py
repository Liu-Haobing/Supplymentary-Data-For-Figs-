import os
import random
import string
import cv2
import numpy as np

WIDTH = 16

def generate_random_string(length=8):
    """生成一个8位随机数"""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def crop_and_save_image(image_path, crop_coords, save_dir, label):
    """裁剪并保存图像"""
    # 读取图片
    img = cv2.imread(image_path)
    # 遍历每个裁剪区域并保存
    for i, coords in enumerate(crop_coords):
        # 提取坐标
        x1, x2 = coords[0]
        y1, y2 = coords[1]
        # 裁剪图像
        cropped_img = img[y1:y2, x1:x2]
        # 生成随机数
        random_string = generate_random_string()
        # 保存裁剪图像
        save_path = os.path.join(save_dir, f"{label}_{random_string}.png")
        cv2.imwrite(save_path, cropped_img)
        print(f"保存裁剪图像到 {save_path}")


def process_images_in_folder(folder_path, save_dir):
    """处理文件夹中的所有图片"""
    # 确保保存文件夹存在
    os.makedirs(save_dir, exist_ok=True)

    # 遍历文件夹中的所有图片文件
    for filename in os.listdir(folder_path):
        if filename.endswith(".png"):
            # 解析文件名，例如'+/- xx.png'
            label = filename.split('.')[0][0]  # '+/-'
            number = filename.split('.')[0]
            number = number.removeprefix('+')
            number = number.removeprefix('-')
            if label =='+' or label == '0':
                label_number = f"{number}"
            else:
                label_number = f"{label}{number}"


            Coords_1 = [[261,218],[517,177],[393,232],[250,361],[501,386]]
            Coords_2 = [[247,247],[465,206],[300,279],[317,378]]
            Coords_3 = [[262,131], [395,176], [407,287], [495,348], [391,411]]
            Coords = Coords_1
            # 构造裁剪区域，可以根据实际情况修改
            crop_coords = [
                [[x-WIDTH, x+WIDTH], [y-WIDTH, y+WIDTH]] for [x,y] in Coords
            ]

            # 获取图片的完整路径
            image_path = os.path.join(folder_path, filename)
            # 调用裁剪和保存函数
            crop_and_save_image(image_path, crop_coords, save_dir, label_number)


# 示例使用
folder_path = '20250803/4-1235'  # 替换为您的文件夹路径
save_dir = 'dataset_1'  # 裁剪图像保存的目标文件夹
process_images_in_folder(folder_path, save_dir)
