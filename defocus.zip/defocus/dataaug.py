import os
import random
from PIL import Image
from torchvision import transforms
from sklearn.model_selection import train_test_split
import glob

# 创建输出文件夹
output_dir = 'dataset_1_aug'
os.makedirs(os.path.join(output_dir, 'train'), exist_ok=True)
os.makedirs(os.path.join(output_dir, 'valid'), exist_ok=True)

# 数据增强操作：旋转、镜像翻转、随机裁剪等
transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),  # 水平翻转
    transforms.RandomVerticalFlip(),    # 垂直翻转
    transforms.ToTensor()
])

# 将数据集中的图片读取并增强
image_dir = 'dataset_1'  # 假设原图像存放路径为'dataset'

# 获取所有图片的路径
image_paths = glob.glob(os.path.join(image_dir, '*.png'))

# 设置随机种子以确保可重复性
random.seed(42)

# 分割数据集：80% 用于训练，20% 用于验证
train_paths, valid_paths = train_test_split(image_paths, test_size=0.2, random_state=42)

# 扩增图片并保存
def augment_and_save(image_paths, split):
    for i, img_path in enumerate(image_paths):
        image = Image.open(img_path).convert('RGB')

        # 进行6倍数据增强（旋转、镜像翻转等）
        for j in range(6):
            # 执行数据增强
            augmented_image = transform(image)

            # 将Tensor转换回PIL图片
            augmented_image_pil = transforms.ToPILImage()(augmented_image)

            # 确定图片保存路径
            img_name = os.path.basename(img_path)
            save_path = os.path.join(output_dir, split, f"{os.path.splitext(img_name)[0]}_aug_{j+1}.png")

            # 保存增强后的图片
            augmented_image_pil.save(save_path)

# 对训练集和验证集分别进行增强并保存
augment_and_save(train_paths, 'train')
augment_and_save(valid_paths, 'valid')

print(f"数据增强完成！增强后的图片已保存到 {output_dir}")
